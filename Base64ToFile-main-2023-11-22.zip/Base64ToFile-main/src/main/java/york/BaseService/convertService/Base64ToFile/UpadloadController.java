package york.BaseService.convertService.Base64ToFile;

import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Base64;


/**
 * @Author York
 * @Date 2022/5/18 1:44 下午
 * @Version 1.0
 */

@Controller
public class UpadloadController {
    private final Logger logger =  LoggerFactory.getLogger(this.getClass());
    @RequestMapping(value = "/upload")
    public void upload(HttpServletRequest request, HttpServletResponse response, MultipartFile file) throws Exception{
        logger.info("###########################################");
        logger.info("新的请求进来了");
        String ipAddress;
        ipAddress = IpUtil.getIpAddr(request);
        logger.info("请求方的ip为: " + ipAddress);
        String base64 = request.getParameter("base64");
        String fileType = request.getParameter("fileType");
        String fileName = request.getParameter("fileName");
        String originalFileName = null;
        originalFileName = file.getOriginalFilename();
        String download_fileName;
        if ("".equals(fileName)) {
            download_fileName = "file";
        } else {
            download_fileName = fileName;
        }
        byte[] data;
        if (!StringUtils.hasText(originalFileName) && !"".equals(base64)) {
            logger.info("文本框形式的base64");
            data = Base64.getDecoder().decode(base64);
        } else {
            logger.info("文件形式的base64");
            StringBuffer sb = new StringBuffer();
            readToBuffer(sb, file);
            data = Base64.getDecoder().decode(sb.toString());
        }
        try {
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=\"" + URLEncoder.encode(String.format("%s.%s", download_fileName, fileType), "UTF-8") + "\"");
            response.setContentLength(data.length);
            response.setHeader("Accept-Ranges", "bytes");
            response.setHeader("Pragma", "no-cache");
            response.setHeader("Cache-Control", "no-cache");
            response.setHeader("Expires", "0");
            OutputStream os = response.getOutputStream();
            os.write(data);
            os.flush();
            os.close();
            logger.info("已成功下载文件 " + URLEncoder.encode(String.format("%s.%s", download_fileName, fileType), "UTF-8"));
            logger.info("###########################################");
        } catch (IOException e1) {
            e1.printStackTrace();
            logger.error("IO异常:{}", e1.getLocalizedMessage() , e1);
            logger.info("###########################################");
            response.sendRedirect("/");
        } catch (NullPointerException e2) {
            e2.printStackTrace();
            logger.error("空指针异常:{}", e2.getLocalizedMessage() , e2);
            logger.info("###########################################");
            response.sendRedirect("/");
        }
    }

    public static void readToBuffer(StringBuffer buffer, MultipartFile file) throws IOException {
        String line; // 用来保存每行读取的内容
        BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
        line = reader.readLine(); // 读取第一行
        while (line != null) { // 如果 line 为空说明读完了
            buffer.append(line); // 将读到的内容添加到 buffer 中
            // buffer.append("\n"); // 添加换行符
            line = reader.readLine(); // 读取下一行
        }
        reader.close();
    }
}
